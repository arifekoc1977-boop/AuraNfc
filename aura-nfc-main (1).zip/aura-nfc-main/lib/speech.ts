export interface SpeechOptions {
  shopName?: string;
  stockCount: number;
  deliveryText?: string;
}

export const playEsnafVoicePitch = ({
  shopName = "Ustam",
  stockCount = 5,
  deliveryText = "bugün 1 saat içinde"
}: SpeechOptions): void => {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

  window.speechSynthesis.cancel();
  const hitab = shopName && shopName.trim() !== "" ? shopName : "Ustam";

  const esnafMetni = `
    Selamün aleyküm ${hitab}! Hayırlı işler, helalinden bereketli kazançlar olsun inşallah. 
    
    Ustam, senin dükkanın haritadaki durumunu ve müşteri potansiyelini arka planda şöyle bir inceledik. Maşallah gelen müşterin memnun, yemeğini yiyen, hizmetini alan duacı olup gidiyor. Ama bak burada çok kritik bir mevzu var: 

    Müşteri dükkandan çıkıp gitti mi, bir daha Google'ı açıp senin dükkanın adını aratmakla, şifre girmekle uğraşmaz. Yorum yapmayı unutur gider. Ama rakipler boş durmuyor ustam; onlar yorum sayısını artırdıkça haritada senin önüne geçiyor.

    Biz de dedik ki, esnaf esnafın halinden anlar. Sana öyle süslü püslü laflar değil, doğrudan işini görecek alet lazım. Bak, masalara ya da kasaya koyacağın bu mat siyah, şampanya sarısı VIP NFC kartı koyuyorsun. Müşteri telefonunu şöyle bir yaklaştırıyor, şak diye 1 saniyede senin Google yorum sayfan açılıyor. Ne arama var, ne şifre var, ne zaman kaybı var! Yıldızı verip yorumunu patlatıyor.

    Ustam, biz öyle uzaktan internetten kart satıp kaybolanlardan değiliz. Kepez'de, Muratpaşa'da kuryemiz sahada dolanıyor. Şu an sistemde baktım, elimizde son ${stockCount} adet VIP kurulum kartımız kalmış. 

    Eğer şimdi siparişini verirsen, kuryemiz ${deliveryText} kapına kadar getiriyor. Masalarına canlı kurulumunu yapıyoruz, telefonla testini birlikte yapıp teslim ediyoruz. Müşteriyi rakiplerin önüne kaptırma ustam, tekli Google kartını ya da Instagram'la ikili paketini seç, işini sağlama alalım!
  `;

  const utterance = new SpeechSynthesisUtterance(esnafMetni);
  utterance.lang = 'tr-TR';
  utterance.rate = 0.93;
  utterance.pitch = 0.95;
  utterance.volume = 1.0;

  window.speechSynthesis.speak(utterance);
};

export const stopEsnafVoice = (): void => {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
};
