'use client'

import { useEffect, useState, useRef } from 'react'
import { ArrowUpRight, Check, ChevronRight, Download, Camera, MapPin, MessageCircle, Phone, ShieldCheck, Sparkles, Star, X, ShoppingBag, AlertTriangle, Radar, Calculator, ShieldAlert, Play, Plus, Trash2 } from 'lucide-react'

type ReferenceShop = {
  id: string
  name: string
  district: string
  image: string
}

type StockSettings = { 
  count: number; 
  orderStatus: string; 
  orderNote: string;
  shops: ReferenceShop[];
}

const initialShops: ReferenceShop[] = [
  { id: '1', name: 'Kültür Lezzet Pide', district: 'Kepez', image: 'https://kommodo.ai/i/hxhLmFcgh5A7aP7Fz4yR' },
  { id: '2', name: 'Lara VIP Coffee', district: 'Muratpaşa', image: 'https://kommodo.ai/i/J6OiFrmqAwVGvUbpjtwW' },
  { id: '3', name: 'Meltem Kebap Salonu', district: 'Muratpaşa', image: 'https://kommodo.ai/i/6gnCwARANmJPqMOBKycu' },
  { id: '4', name: 'Işıklar VIP Berber', district: 'Muratpaşa', image: 'https://kommodo.ai/i/hxhLmFcgh5A7aP7Fz4yR' },
  { id: '5', name: 'Varsak Otomotiv', district: 'Kepez', image: 'https://kommodo.ai/i/J6OiFrmqAwVGvUbpjtwW' },
]

const defaults: StockSettings = {
  count: 5,
  orderStatus: 'Saha Kuryesi Sahada Aktif',
  orderNote: 'Kepez & Muratpaşa bölgesinde adrese teslim canlı kurulum yapıyoruz.',
  shops: initialShops,
}

const products = [
  {
    id: 'google-nfc',
    name: 'Aura Google Yorum NFC Kartı',
    note: 'Tekli VIP Kart',
    detail: 'Müşteriniz telefonunu yaklaştırdığı an Google yorum sayfanız açılır. Masalar ve kasa için idealdir.',
    price: 225,
    image: 'https://kommodo.ai/i/hxhLmFcgh5A7aP7Fz4yR',
    href: 'https://www.shopier.com/LezzetveKolaylikDogital/51705239',
    icon: Star,
  },
  {
    id: 'instagram-nfc',
    name: 'Aura Instagram Takipçi NFC Kartı',
    note: 'Tekli VIP Kart',
    detail: 'Müşterilerinizi doğrudan Instagram profilinize yönlendirir. Takipçi ve etkileşimi artırır.',
    price: 225,
    image: 'https://kommodo.ai/i/J6OiFrmqAwVGvUbpjtwW',
    href: 'https://www.shopier.com/LezzetveKolaylikDogital/51705340',
    icon: Camera,
  },
  {
    id: 'vip-bundle',
    name: 'Aura Google + Instagram VIP Paket',
    note: 'Fırsat Paketi · Önerilen',
    detail: 'Hem Google yorumlarınızı hem de Instagram kitlenizi büyüten ikili avantajlı VIP set.',
    price: 360,
    oldPrice: 450,
    image: 'https://kommodo.ai/i/6gnCwARANmJPqMOBKycu',
    href: 'https://www.shopier.com/LezzetveKolaylikDogital/51705365',
    icon: Sparkles,
  },
]

export default function Page() {
  const [shopName, setShopName] = useState('')
  const [district, setDistrict] = useState('Kepez')
  const [settings, setSettings] = useState<StockSettings>(defaults)
  const [pinOpen, setPinOpen] = useState(false)
  const [adminOpen, setAdminOpen] = useState(false)
  const [pin, setPin] = useState('')
  const [simulating, setSimulating] = useState(false)
  const [dailyCustomers, setDailyCustomers] = useState(40)
  
  // Yeni Dükkan Ekleme Admin State
  const [newShopName, setNewShopName] = useState('')
  const [newShopDistrict, setNewShopDistrict] = useState('Kepez')
  const [newShopImg, setNewShopImg] = useState('')

  const taps = useRef<number[]>([])

  useEffect(() => {
    const saved = window.localStorage.getItem('aura-nfc-settings')
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        setSettings({ ...defaults, ...parsed })
      } catch (e) {
        console.error(e)
      }
    }
    document.title = "Aura NFC | Antalya VIP NFC Google & Instagram Kartları"
  }, [])

  const saveSettings = (next: StockSettings) => {
    setSettings(next)
    window.localStorage.setItem('aura-nfc-settings', JSON.stringify(next))
  }

  const handleOrder = (productHref: string) => {
    if (!shopName.trim()) {
      alert('Lütfen önce dükkan adınızı veya konumunuzu girin!')
      return
    }
    window.open(productHref, '_blank')
  }

  const handleAddShop = () => {
    if (!newShopName.trim()) return alert('Dükkan adı gerekli!')
    const imgUrl = newShopImg.trim() || 'https://kommodo.ai/i/hxhLmFcgh5A7aP7Fz4yR'
    const newEntry: ReferenceShop = {
      id: Date.now().toString(),
      name: newShopName,
      district: newShopDistrict,
      image: imgUrl,
    }
    
    // Otomatik Kayan Sıra Mantığı: En başa ekler, 5 taneden fazlasını otomatik (en eskiyi) siler
    const updatedShops = [newEntry, ...settings.shops].slice(0, 5)
    saveSettings({ ...settings, shops: updatedShops })
    
    setNewShopName('')
    setNewShopImg('')
    alert('Dükkan eklendi! Sıradaki ilk dükkan oldu, en eski dükkan devredışından çıktı.')
  }

  const handleLogoTap = () => {
    const now = Date.now(); 
    taps.current = [...taps.current.filter((time) => now - time < 650), now]
    if (taps.current.length >= 3) { setPinOpen(true); taps.current = [] }
  }

  const submitPin = () => {
    if (pin === '0707') { setPinOpen(false); setAdminOpen(true); setPin('') }
    else { alert('Hatalı PIN'); setPin('') }
  }

  const runSimulation = () => {
    setSimulating(true)
    setTimeout(() => {
      setSimulating(false)
      window.open('https://maps.google.com', '_blank')
    }, 1500)
  }

  const downloadVcard = () => {
    const vcard = ['BEGIN:VCARD', 'VERSION:3.0', 'FN:Aura NFC Saha Kuryesi', 'ORG:Aura NFC / Antalya', 'TEL:+905519279532', 'NOTE:Antalya Kepez ve Muratpaşa VIP NFC çözümleri', 'END:VCARD'].join('\n')
    const blob = new Blob([vcard], { type: 'text/vcard;charset=utf-8' })
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = 'Aura_NFC_Saha_Kurye.vcf'; link.click(); URL.revokeObjectURL(link.href)
  }

  const isStockAvailable = settings.count > 0
  const monthlyReviews = Math.round(dailyCustomers * 0.25 * 30) // %25 dönüşüm tahmini

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#0b0b0c] pb-32 text-[#f7f4ed] selection:bg-[#d4af37]/30">
      <div className="pointer-events-none fixed inset-0 opacity-60 [background-image:radial-gradient(circle_at_50%_-10%,rgba(212,175,55,.17),transparent_34%),linear-gradient(rgba(255,255,255,.018)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.018)_1px,transparent_1px)] [background-size:auto,36px_36px,36px_36px]" />
      
      {/* Üst Bar */}
      <header className="relative mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5 md:px-10 md:py-7">
        <button onClick={handleLogoTap} aria-label="Aura NFC Ana Sayfa" className="group text-left">
          <span className="block text-xs font-bold uppercase tracking-[.42em] text-[#d4af37]">AURA NFC</span>
          <span className="font-serif text-sm tracking-[.18em] text-white/70">ANTALYA VIP DIGITALS</span>
        </button>
        
        {/* Canlı Stok Rozeti */}
        <div className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] uppercase tracking-[.15em] ${isStockAvailable ? 'border-[#d4af37]/30 bg-[#d4af37]/10 text-[#e5c158]' : 'border-red-500/30 bg-red-500/10 text-red-400'}`}>
          <span className={`size-2 rounded-full ${isStockAvailable ? 'bg-[#d4af37] shadow-[0_0_8px_#d4af37]' : 'bg-red-500 animate-pulse'}`} />
          {isStockAvailable ? `Saha Stoğu: ${settings.count} Adet Hazır` : 'Stok Tükendi (3-5 Güne Gelir)'}
        </div>
      </header>

      {/* Hero Alanı */}
      <section className="relative mx-auto max-w-6xl px-5 pb-8 pt-8 md:px-10 md:pb-12 md:pt-12">
        <div className="max-w-3xl">
          <div className="mb-4 flex items-center gap-3 text-xs uppercase tracking-[.25em] text-[#d4af37]">
            <span className="h-px w-10 bg-[#d4af37]" /> Aura NFC Akıllı Restoran & Kafe Sistemleri
          </div>
          <h1 className="font-serif text-4xl leading-[1.05] tracking-[-.03em] text-white sm:text-6xl md:text-7xl">
            Müşterilerinizi<br /><em className="font-normal text-[#d4af37]">tek dokunuşla</em> kazanın.
          </h1>
          <p className="mt-5 max-w-xl text-sm leading-6 text-white/60 md:text-base">
            Kepez ve Muratpaşa bölgesindeki işletmeniz için siparişinizi verin, saha kuryemiz adrese gelip masalarınıza canlı kurulum yapsın.
          </p>
        </div>

        {/* Dükkan Konum Giriş Kutusu */}
        <div className="mt-8 max-w-3xl rounded-2xl border border-[#d4af37]/30 bg-white/[.04] p-4 shadow-2xl backdrop-blur-xl">
          <p className="text-xs uppercase tracking-widest text-[#d4af37] mb-2 font-medium">1. Adım: İşletme Konum Bilgisi</p>
          <div className="grid gap-3 sm:grid-cols-3">
            <input 
              type="text" 
              value={shopName} 
              onChange={(e) => setShopName(e.target.value)} 
              placeholder="Dükkan / İşletme Adınız" 
              className="sm:col-span-2 w-full rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none focus:border-[#d4af37] placeholder:text-white/30" 
            />
            <select 
              value={district} 
              onChange={(e) => setDistrict(e.target.value)}
              className="w-full rounded-xl border border-white/10 bg-[#151517] px-4 py-3 text-sm text-white outline-none focus:border-[#d4af37]"
            >
              <option value="Kepez">Kepez</option>
              <option value="Muratpaşa">Muratpaşa</option>
              <option value="Konyaaltı">Konyaaltı (Min. 6 Adet)</option>
            </select>
          </div>
        </div>

        {/* 1. Özellik: Canlı Kart Denemesi (Simülasyon Modu) */}
        <div className="mt-4 max-w-3xl rounded-2xl border border-[#d4af37]/20 bg-[#141310] p-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#d4af37]/10 text-[#d4af37] border border-[#d4af37]/20">
              <Sparkles size={20} />
            </div>
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-white">NFC Kartı Şimdi Canlı Deneyin</h4>
              <p className="text-xs text-white/50 mt-0.5">Müşteri telefonunu karta dokundurduğunda ne olacağını görün.</p>
            </div>
          </div>
          <button 
            onClick={runSimulation}
            disabled={simulating}
            className="flex items-center gap-2 rounded-xl bg-[#d4af37] text-black font-bold px-4 py-2.5 text-xs hover:brightness-110 active:scale-95 transition shrink-0"
          >
            <Play size={14} fill="currentColor" />
            {simulating ? 'Okunuyor...' : 'Test Et'}
          </button>
        </div>
      </section>

      {/* 2. Özellik: Otomatik Kayan Fotoğraflı Son 5 Dükkan Akışı */}
      <section className="relative my-8 overflow-hidden py-4 border-y border-white/10 bg-black/30">
        <div className="max-w-6xl mx-auto px-5 mb-3 flex items-center justify-between">
          <span className="text-[11px] uppercase tracking-[.25em] text-[#d4af37] font-semibold flex items-center gap-2">
            <Radar size={14} className="animate-spin text-[#d4af37]" /> Antalya Bölgesinde Son Kurulum Yapılan 5 İşletme
          </span>
          <span className="text-[10px] text-white/40">Canlı Kurye Güncellemesi</span>
        </div>
        
        {/* Kayan Şerit */}
        <div className="flex gap-4 overflow-x-auto pb-2 px-5 no-scrollbar">
          {settings.shops.map((shop) => (
            <div key={shop.id} className="flex-none w-64 rounded-xl border border-white/10 bg-[#151517] p-2.5 flex items-center gap-3">
              <img src={shop.image} alt={shop.name} className="w-12 h-12 rounded-lg object-cover border border-white/10" />
              <div className="overflow-hidden">
                <h5 className="text-xs font-bold text-white truncate">{shop.name}</h5>
                <p className="text-[10px] text-[#d4af37]">{shop.district} / Antalya</p>
                <span className="inline-block text-[9px] text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded border border-green-500/20 mt-1">
                  VIP Kurulum Tamamlandı
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Özellik: Yorum Potansiyeli Hesaplama Cetveli */}
      <section className="relative mx-auto max-w-6xl px-5 my-10 md:px-10">
        <div className="rounded-2xl border border-[#d4af37]/30 bg-gradient-to-r from-[#171612] to-[#0e0e0f] p-6 shadow-2xl md:p-8">
          <div className="flex items-center gap-2 text-xs uppercase tracking-[.25em] text-[#d4af37] mb-2">
            <Calculator size={16} /> Potansiyel Hesaplayıcı
          </div>
          <h3 className="font-serif text-2xl text-white">İşletmeniz Ayda Kaç Yeni Yorum Kazanır?</h3>
          <p className="text-xs text-white/50 mt-1">Günde ağırladığınız ortalama masa/müşteri sayısını kaydırın:</p>

          <div className="mt-6 grid gap-6 md:grid-cols-2 items-center">
            <div>
              <div className="flex justify-between text-xs text-white/70 mb-2 font-medium">
                <span>Günlük Müşteri Sayısı: <strong className="text-[#d4af37] text-sm">{dailyCustomers} Masa/Kişi</strong></span>
              </div>
              <input 
                type="range" 
                min="10" 
                max="200" 
                step="5" 
                value={dailyCustomers} 
                onChange={(e) => setDailyCustomers(Number(e.target.value))}
                className="w-full accent-[#d4af37] bg-white/10 rounded-lg cursor-pointer h-2"
              />
            </div>

            <div className="rounded-xl border border-[#d4af37]/20 bg-black/40 p-4 text-center">
              <span className="text-[10px] uppercase tracking-widest text-white/40 block">Tahmini Aylık Yeni Google Yorumu</span>
              <span className="font-serif text-4xl text-[#e5c158] font-bold mt-1 block">+{monthlyReviews} Yorum</span>
              <span className="text-[10px] text-green-400 mt-1 block">Google Arama Haritasında Üst Sıraya Geçiş Riski %0</span>
            </div>
          </div>
        </div>
      </section>

      {/* Ürün Listesi */}
      <section className="relative mx-auto max-w-6xl px-5 md:px-10">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-serif text-2xl text-white md:text-3xl">Aura NFC VIP Ürünler</h2>
          {!isStockAvailable && (
            <span className="flex items-center gap-1.5 text-xs text-amber-400 bg-amber-400/10 px-3 py-1.5 rounded-lg border border-amber-400/20">
              <AlertTriangle size={14} /> Yeni kurye stoğu 3-5 gün içinde sahada olacak
            </span>
          )}
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          {products.map((product, index) => { 
            return (
              <article key={product.id} className={`group relative overflow-hidden rounded-2xl border bg-white/[.04] p-4 backdrop-blur-xl transition duration-300 hover:-translate-y-1 ${index === 2 ? 'border-[#d4af37] shadow-[0_0_25px_rgba(212,175,55,.15)]' : 'border-white/10'}`}>
                
                {/* Ürün Resmi */}
                <div className="relative aspect-[1.4] overflow-hidden rounded-xl border border-white/10 bg-[#131315]">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0c]/80 via-transparent to-transparent" />
                  {index === 2 && (
                    <span className="absolute left-3 top-3 rounded-full bg-[#d4af37] px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-black">
                      Özel VIP Set
                    </span>
                  )}
                </div>

                {/* İçerik */}
                <div className="pt-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-medium text-white text-base">{product.name}</h3>
                      <p className="text-xs text-[#d4af37] mt-0.5">{product.note}</p>
                    </div>
                    <div className="text-right">
                      {product.oldPrice && <del className="block text-xs text-white/40">{product.oldPrice} TL</del>}
                      <span className="text-lg font-bold text-[#e5c158]">{product.price} TL</span>
                    </div>
                  </div>

                  <p className="mt-3 text-xs leading-5 text-white/50 min-h-[40px]">{product.detail}</p>

                  <button 
                    onClick={() => handleOrder(product.href)}
                    className={`mt-4 w-full flex items-center justify-center gap-2 rounded-xl py-3 text-xs font-bold transition shadow-lg ${isStockAvailable ? 'bg-gradient-to-r from-[#c39b2d] to-[#edcf68] text-black hover:brightness-110' : 'bg-gray-800 text-gray-400 border border-gray-700'}`}
                  >
                    <ShoppingBag size={14} />
                    {isStockAvailable ? 'Sipariş Ver (Adrese Kurulum)' : 'Ön Sipariş Ver (3-5 Güne Gelir)'}
                  </button>
                </div>
              </article>
            ) 
          })}
        </div>
      </section>

      {/* 5. Özellik: 5 Gün İade Garantisi Rozeti */}
      <section className="relative mx-auto max-w-6xl px-5 my-12 md:px-10">
        <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-[#d4af37] text-black rounded-2xl shrink-0">
              <ShieldAlert size={28} />
            </div>
            <div>
              <h4 className="font-serif text-xl text-white">5 Gün İçinde Verim Alamazsanız Paranız İade!</h4>
              <p className="text-xs text-white/60 mt-1 max-w-xl">
                Aura NFC kartlarını işletmenize kuruyoruz. 5 gün boyunca masalarınızda deneyin. Eğer yorumlarınızda ve görünürlüğünüzde belirgin bir artış hissetmezseniz kartı iade alıyor, ücretinizi şartsız iade ediyoruz.
              </p>
            </div>
          </div>
          <span className="shrink-0 text-xs font-bold text-[#d4af37] uppercase tracking-widest border border-[#d4af37]/40 px-4 py-2 rounded-xl">
            %100 Risk Sıfır
          </span>
        </div>
      </section>

      {/* Alt Navigasyon */}
      <nav className="fixed inset-x-3 bottom-3 z-20 mx-auto flex max-w-5xl flex-wrap items-center justify-center gap-2 rounded-2xl border border-white/10 bg-[#171719]/95 p-2 shadow-2xl backdrop-blur-xl">
        <a href="tel:+905519279532" className="flex flex-1 items-center justify-center gap-2 rounded-xl px-2 py-2.5 text-xs text-white/80 transition hover:bg-white/10">
          <Phone size={14} /> <span>Tıkla Ara</span>
        </a>
        <a href="https://wa.me/905519279532" target="_blank" rel="noreferrer" className="flex flex-1 items-center justify-center gap-2 rounded-xl px-2 py-2.5 text-xs text-white/80 transition hover:bg-white/10">
          <MessageCircle size={14} /> <span>WhatsApp VIP</span>
        </a>
        <button onClick={downloadVcard} className="flex flex-1 items-center justify-center gap-2 rounded-xl px-2 py-2.5 text-xs text-white/80 transition hover:bg-white/10">
          <Download size={14} /> <span>Rehbere Kaydet</span>
        </button>
      </nav>

      {/* Admin Panel (Stok & Dükkan Yönetimi) */}
      {adminOpen && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/80 p-5 backdrop-blur-md overflow-y-auto">
          <div className="w-full max-w-md rounded-2xl border border-[#d4af37]/30 bg-[#151517] p-6 shadow-2xl text-white my-8">
            <div className="flex justify-between items-center mb-4 border-b border-white/10 pb-3">
              <h3 className="text-lg font-bold text-[#d4af37]">Aura NFC Saha Paneli</h3>
              <button onClick={() => setAdminOpen(false)}><X size={18} /></button>
            </div>
            
            <div className="space-y-5">
              {/* Stok Ayarı */}
              <div>
                <label className="text-xs text-gray-400 font-bold uppercase">Görünen Stok Adedi</label>
                <input 
                  type="number" 
                  value={settings.count} 
                  onChange={(e) => saveSettings({ ...settings, count: Number(e.target.value) })} 
                  className="w-full mt-1 bg-black/50 border border-gray-700 rounded-xl p-3 text-white outline-none focus:border-[#d4af37]"
                />
              </div>

              {/* Yeni Referans Dükkan Ekleme (Son 5 Dükkan Yönetimi) */}
              <div className="border-t border-white/10 pt-4">
                <label className="text-xs text-gray-400 font-bold uppercase block mb-2">Yeni Referans Dükkan Ekle (Son 5'e Kayar)</label>
                <div className="space-y-2">
                  <input 
                    type="text" 
                    placeholder="Dükkan Adı (Örn: Kültür Pide)"
                    value={newShopName}
                    onChange={(e) => setNewShopName(e.target.value)}
                    className="w-full bg-black/50 border border-gray-700 rounded-xl p-2.5 text-xs text-white outline-none"
                  />
                  <select 
                    value={newShopDistrict}
                    onChange={(e) => setNewShopDistrict(e.target.value)}
                    className="w-full bg-[#111] border border-gray-700 rounded-xl p-2.5 text-xs text-white outline-none"
                  >
                    <option value="Kepez">Kepez</option>
                    <option value="Muratpaşa">Muratpaşa</option>
                    <option value="Konyaaltı">Konyaaltı</option>
                  </select>
                  <input 
                    type="text" 
                    placeholder="Fotoğraf Görsel URL (Boş kalırsa varsayılan)"
                    value={newShopImg}
                    onChange={(e) => setNewShopImg(e.target.value)}
                    className="w-full bg-black/50 border border-gray-700 rounded-xl p-2.5 text-xs text-white outline-none"
                  />
                  <button 
                    onClick={handleAddShop}
                    className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1 mt-1"
                  >
                    <Plus size={14} /> Dükkanı Başa Ekle (Eski Silinir)
                  </button>
                </div>
              </div>

              <button onClick={() => setAdminOpen(false)} className="w-full bg-[#d4af37] text-black font-bold py-3 rounded-xl mt-4">
                Kaydet ve Kapat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PIN Girişi Modal */}
      {pinOpen && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/80 p-5 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl border border-[#d4af37]/30 bg-[#151517] p-6 text-center text-white">
            <h3 className="text-lg font-bold text-[#d4af37]">Aura Panel Girişi</h3>
            <input 
              type="password" 
              maxLength={4} 
              value={pin} 
              onChange={(e) => setPin(e.target.value)} 
              placeholder="PIN (0707)" 
              className="w-full mt-4 bg-black/50 border border-gray-700 rounded-xl p-3 text-center text-2xl tracking-widest text-white outline-none focus:border-[#d4af37]"
            />
            <button onClick={submitPin} className="w-full bg-[#d4af37] text-black font-bold py-3 rounded-xl mt-4">Giriş Yap</button>
          </div>
        </div>
      )}
    </main>
  )
}
